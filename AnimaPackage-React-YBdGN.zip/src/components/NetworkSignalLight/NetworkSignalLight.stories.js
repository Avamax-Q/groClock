import { NetworkSignalLight } from ".";

export default {
  title: "Components/NetworkSignalLight",
  component: NetworkSignalLight,
  argTypes: {
    strength: {
      options: ["four-bars", "two-bars", "zero-bars", "three-bars", "one-bars"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    strength: "four-bars",
    className: {},
  },
};
