/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const WifiSignalLight = ({ property1, className }) => {
  return (
    <img
      className={`wifi-signal-light ${className}`}
      alt="Property bars"
      src={
        property1 === "three-bars"
          ? "/img/property-1-3-bars.png"
          : property1 === "two-bars"
          ? "/img/property-1-2-bars.png"
          : property1 === "one-bars"
          ? "/img/property-1-1-bars.png"
          : "/img/property-1-variant5.png"
      }
    />
  );
};

WifiSignalLight.propTypes = {
  property1: PropTypes.oneOf(["two-bars", "zero-bars", "three-bars", "variant-5", "one-bars"]),
};
