import { StatusBar } from ".";

export default {
  title: "Components/StatusBar",
  component: StatusBar,
};

export const Default = {
  args: {
    darkMode: true,
    className: {},
    overlapGroupClassName: {},
    notchClassName: {},
    notch: "/img/notch-1.png",
    statusIconsClassName: {},
    indicatorTypeCameraClassName: {},
    timeLightColorRedClassName: {},
  },
};
