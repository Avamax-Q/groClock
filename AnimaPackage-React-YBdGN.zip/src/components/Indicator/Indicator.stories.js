import { Indicator } from ".";

export default {
  title: "Components/Indicator",
  component: Indicator,
  argTypes: {
    type: {
      options: ["microphone", "none", "camera"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    type: "microphone",
    className: {},
  },
};
