import React from "react";
import { StatusBar } from "../../components/StatusBar";
import { User } from "../../components/User";
import "./style.css";

export const Verify = () => {
  return (
    <div className="verify">
      <div className="div">
        <div className="overlap">
          <div className="rectangle" />
          <div className="text-wrapper">Lets Start</div>
        </div>
        <div className="overlap-2">
          <div className="ellipse" />
          <div className="ellipse-2" />
          <StatusBar
            className="status-bar-instance"
            darkMode={false}
            indicatorTypeCameraClassName="status-bar-4"
            notch="/img/notch-2.png"
            notchClassName="status-bar-2"
            overlapGroupClassName="design-component-instance-node"
            statusIconsClassName="status-bar-3"
            timeLightColorRedClassName="status-bar-5"
          />
          <div className="text-wrapper-2">Login</div>
          <User className="user-instance" user="/img/user-1.png" />
          <p className="grocery-clock">
            <span className="span">Grocery </span>
            <span className="text-wrapper-3">Clock</span>
          </p>
        </div>
        <div className="rectangle-2" />
        <div className="rectangle-3" />
        <div className="rectangle-4" />
        <div className="rectangle-5" />
        <p className="p">Enter OTP sent to your email Address</p>
      </div>
    </div>
  );
};
