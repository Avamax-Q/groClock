export { PicGalleryPage } from "./PicGalleryPage";
