import React from "react";
import { NetworkSignalLight } from "../../components/NetworkSignalLight";
import { TimeLight } from "../../components/TimeLight";
import { User } from "../../components/User";
import { WifiSignalLight } from "../../components/WifiSignalLight";
import "./style.css";

export const PicGalleryPage = () => {
  return (
    <div className="pic-gallery-page">
      <div className="div">
        <div className="overlap">
          <div className="ellipse" />
          <div className="status-bar">
            <div className="overlap-group">
              <img className="notch" alt="Notch" src="/img/notch.png" />
              <div className="status-icons">
                <NetworkSignalLight className="design-component-instance-node" strength="three-bars" />
                <WifiSignalLight className="design-component-instance-node" property1="three-bars" />
                <img className="battery-light" alt="Battery light" src="/img/battery-light-1.png" />
              </div>
              <TimeLight className="time-light-instance" color="clear" />
            </div>
          </div>
          <User className="user-instance" user="/img/user-1.png" />
        </div>
        <div className="overlap-2">
          <div className="ellipse-2" />
          <img className="icon-menu" alt="Icon menu" src="/img/icon-menu.png" />
          <img className="icon-shopping-bag" alt="Icon shopping bag" src="/img/icon-shopping-bag.png" />
          <div className="ellipse-3" />
          <img className="icon-home" alt="Icon home" src="/img/icon-home.png" />
        </div>
        <img className="vector" alt="Vector" src="/img/vector-10.png" />
        <img className="img" alt="Vector" src="/img/vector-10.png" />
        <img className="vector-2" alt="Vector" src="/img/vector-10.png" />
        <img className="vector-3" alt="Vector" src="/img/vector-10.png" />
        <img className="vector-4" alt="Vector" src="/img/vector-10.png" />
        <img className="vector-5" alt="Vector" src="/img/vector-10.png" />
        <img className="vector-6" alt="Vector" src="/img/vector-10.png" />
        <div className="text-wrapper">Account Settings</div>
        <div className="text-wrapper-2">Notification Settings</div>
        <div className="text-wrapper-3">Setting Settings</div>
        <div className="group">
          <div className="overlap-3">
            <div className="rectangle" />
            <img className="icon-arrow-right" alt="Icon arrow right" src="/img/icon-arrow-right.png" />
          </div>
        </div>
        <div className="text-wrapper-4">Recipe Settings</div>
        <div className="text-wrapper-5">About Us</div>
        <div className="text-wrapper-6">Display Settings</div>
      </div>
    </div>
  );
};
