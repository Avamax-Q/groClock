import { WifiSignalLight } from ".";

export default {
  title: "Components/WifiSignalLight",
  component: WifiSignalLight,
  argTypes: {
    property1: {
      options: ["two-bars", "zero-bars", "three-bars", "variant-5", "one-bars"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "two-bars",
    className: {},
  },
};
