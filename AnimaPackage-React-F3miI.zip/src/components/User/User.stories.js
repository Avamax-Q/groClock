import { User } from ".";

export default {
  title: "Components/User",
  component: User,
};

export const Default = {
  args: {
    className: {},
    user: "/img/user.png",
  },
};
