/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Indicator } from "../Indicator";
import { NetworkSignalLight } from "../NetworkSignalLight";
import { TimeLight } from "../TimeLight";
import { WifiSignalLight } from "../WifiSignalLight";
import "./style.css";

export const StatusBar = ({
  darkMode,
  className,
  overlapGroupClassName,
  notchClassName,
  notch = "/img/notch-2.png",
  statusIconsClassName,
  indicatorTypeCameraClassName,
  timeLightColorRedClassName,
}) => {
  return (
    <div className={`status-bar ${className}`}>
      <div className={`overlap-group ${overlapGroupClassName}`}>
        <img className={`notch ${notchClassName}`} alt="Notch" src={notch} />
        <div className={`status-icons ${statusIconsClassName}`}>
          {!darkMode && (
            <>
              <NetworkSignalLight className="instance-node" strength="three-bars" />
              <WifiSignalLight className="instance-node" property1="three-bars" />
            </>
          )}

          <img
            className={`battery-light dark-mode-${darkMode}`}
            alt="Battery light"
            src={darkMode ? "/img/network-signal-dark.png" : "/img/battery-light-1.png"}
          />
          {darkMode && (
            <>
              <img className="wifi-signal-dark" alt="Wifi signal dark" src="/img/wifi-signal-dark.png" />
              <img className="battery-dark" alt="Battery dark" src="/img/battery-dark.png" />
            </>
          )}
        </div>
        <Indicator className={indicatorTypeCameraClassName} type="none" />
        {darkMode && <img className="time-dark" alt="Time dark" src="/img/time-dark.png" />}

        {!darkMode && <TimeLight className={timeLightColorRedClassName} color="clear" />}
      </div>
    </div>
  );
};

StatusBar.propTypes = {
  darkMode: PropTypes.bool,
  notch: PropTypes.string,
};
