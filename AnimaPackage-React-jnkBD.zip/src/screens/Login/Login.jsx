import React from "react";
import { StatusBar } from "../../components/StatusBar";
import { User } from "../../components/User";
import "./style.css";

export const Login = () => {
  return (
    <div className="login">
      <div className="div">
        <div className="overlap">
          <div className="ellipse" />
          <div className="ellipse-2" />
          <div className="text-wrapper">Login</div>
          <StatusBar
            className="status-bar-instance"
            darkMode={false}
            indicatorTypeCameraClassName="status-bar-4"
            notch="/img/notch-1.png"
            notchClassName="status-bar-2"
            overlapGroupClassName="design-component-instance-node"
            statusIconsClassName="status-bar-3"
            timeLightColorRedClassName="status-bar-5"
          />
          <p className="grocery-clock">
            <span className="span">Grocery </span>
            <span className="text-wrapper-2">Clock</span>
          </p>
          <img className="india-IN" alt="India IN" src="/img/india-in.png" />
          <div className="group">
            <div className="caretdown-wrapper">
              <img className="caretdown" alt="Caretdown" src="/img/caretdown.png" />
            </div>
          </div>
          <User className="user-instance" user="/img/user-1.png" />
        </div>
        <div className="div-wrapper">
          <div className="text-wrapper-3">Enter email ID</div>
        </div>
        <div className="overlap-2">
          <div className="rectangle" />
          <div className="text-wrapper-4">Login</div>
        </div>
        <div className="overlap-3">
          <div className="text-wrapper-3">Enter password</div>
        </div>
        <div className="text-wrapper-5">Forgot Password ?</div>
        <img className="vector" alt="Vector" src="/img/vector-3.png" />
        <p className="not-registered-yet">
          <span className="text-wrapper-6">Not registered yet ? </span>
          <span className="text-wrapper-7">Create an Account</span>
        </p>
      </div>
    </div>
  );
};
