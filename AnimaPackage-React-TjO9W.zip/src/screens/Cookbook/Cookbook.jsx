import React from "react";
import { StatusBar } from "../../components/StatusBar";
import { User } from "../../components/User";
import "./style.css";

export const Cookbook = () => {
  return (
    <div className="cookbook">
      <div className="div">
        <div className="overlap">
          <div className="ellipse" />
          <StatusBar
            className="status-bar-instance"
            darkMode={false}
            indicatorTypeCameraClassName="status-bar-4"
            notch="/img/notch-2.png"
            notchClassName="status-bar-2"
            overlapGroupClassName="design-component-instance-node"
            statusIconsClassName="status-bar-3"
            timeLightColorRedClassName="status-bar-5"
          />
          <User className="user-instance" user="/img/user-1.png" />
          <div className="group">
            <div className="overlap-2">
              <div className="text-wrapper">Select Cuisine</div>
              <img className="india-IN" alt="India IN" src="/img/india-in.png" />
              <img className="img" alt="Group" src="/img/group-77.png" />
            </div>
            <img className="icon-search-normal" alt="Icon search normal" src="/img/icon-search-normal-1.png" />
          </div>
          <img className="ellipse-2" alt="Ellipse" src="/img/ellipse-48.png" />
          <div className="text-wrapper-2">Your Cookbook !</div>
        </div>
        <div className="overlap-wrapper">
          <div className="overlap-3">
            <div className="ellipse-3" />
            <img className="icon-menu" alt="Icon menu" src="/img/icon-menu.png" />
            <img className="icon-shopping-bag" alt="Icon shopping bag" src="/img/icon-shopping-bag.png" />
            <div className="ellipse-4" />
            <img className="icon-home" alt="Icon home" src="/img/icon-home.png" />
          </div>
        </div>
        <div className="overlap-group-wrapper">
          <div className="overlap-4">
            <div className="overlap-5">
              <div className="text-wrapper-3">Red Chilli Powder</div>
              <div className="text-wrapper-4">Garlic</div>
            </div>
            <div className="text-wrapper-5">Shakshuka</div>
            <div className="overlap-group-2">
              <div className="text-wrapper-3">Brown Eggs</div>
              <div className="text-wrapper-4">Red Peppers</div>
              <div className="text-wrapper-6">Parmesean Cheese</div>
              <div className="text-wrapper-7">Brown Bread</div>
            </div>
            <div className="text-wrapper-8">Ingredients Used</div>
            <div className="text-wrapper-9">Pantry Staples Required</div>
          </div>
        </div>
        <div className="div-wrapper">
          <div className="overlap-4">
            <div className="overlap-6">
              <div className="text-wrapper-3">Seasonings</div>
              <div className="text-wrapper-4">Mayonnaise</div>
            </div>
            <div className="text-wrapper-10">Grilled Chicken Sandwich</div>
            <div className="overlap-group-2">
              <div className="text-wrapper-3">Chicken Thighs</div>
              <div className="text-wrapper-4">Red Peppers</div>
              <div className="text-wrapper-6">Parmesean Cheese</div>
              <div className="text-wrapper-7">Brown Bread</div>
            </div>
            <div className="text-wrapper-8">Ingredients Used</div>
            <div className="text-wrapper-9">Pantry Staples Required</div>
          </div>
        </div>
      </div>
    </div>
  );
};
