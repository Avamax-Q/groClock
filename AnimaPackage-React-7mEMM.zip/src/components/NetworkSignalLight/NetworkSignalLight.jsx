/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const NetworkSignalLight = ({ strength, className }) => {
  return (
    <img
      className={`network-signal-light ${className}`}
      alt="Strength bars"
      src={
        strength === "three-bars"
          ? "/img/strength-3-bars.png"
          : strength === "two-bars"
          ? "/img/strength-2-bars.png"
          : strength === "one-bars"
          ? "/img/strength-1-bars.png"
          : strength === "zero-bars"
          ? "/img/strength-0-bars.png"
          : "/img/strength-4-bars.png"
      }
    />
  );
};

NetworkSignalLight.propTypes = {
  strength: PropTypes.oneOf(["four-bars", "two-bars", "zero-bars", "three-bars", "one-bars"]),
};
