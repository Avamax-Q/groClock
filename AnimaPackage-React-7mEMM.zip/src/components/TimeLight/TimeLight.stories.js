import { TimeLight } from ".";

export default {
  title: "Components/TimeLight",
  component: TimeLight,
  argTypes: {
    color: {
      options: ["clear", "blue", "red", "green"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    color: "clear",
    className: {},
  },
};
