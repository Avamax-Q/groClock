import React from "react";
import { StatusBar } from "../../components/StatusBar";
import { User } from "../../components/User";
import "./style.css";

export const DaFridge = () => {
  return (
    <div className="da-fridge">
      <div className="div">
        <div className="overlap">
          <img className="ellipse" alt="Ellipse" src="/img/ellipse-48.png" />
          <img className="img" alt="Ellipse" src="/img/ellipse-47.png" />
          <div className="group">
            <div className="overlap-group-2">
              <div className="text-wrapper">Red Peppers</div>
              <div className="text-wrapper-2">1 day</div>
            </div>
          </div>
          <div className="overlap-wrapper">
            <div className="overlap-group-2">
              <div className="text-wrapper-3">Parmesan Cheese</div>
              <div className="text-wrapper-4">1 day</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-2">
              <img className="rectangle-stroke" alt="Rectangle stroke" src="/img/rectangle-192-stroke.png" />
              <div className="text-wrapper-3">Chicken Thighs</div>
              <div className="text-wrapper-5">4 days</div>
              <img className="icon-trash" alt="Icon trash" src="/img/icon-trash-2.png" />
              <img className="icon-half-cookie" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
            </div>
            <div className="text-wrapper-6">Expiring In</div>
            <img className="icon-trash-2" alt="Icon trash" src="/img/icon-trash-2.png" />
            <img className="icon-half-cookie-2" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
            <img className="icon-trash-3" alt="Icon trash" src="/img/icon-trash-2.png" />
            <img className="icon-half-cookie-3" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
          </div>
          <StatusBar
            className="status-bar-instance"
            darkMode={false}
            indicatorTypeCameraClassName="status-bar-4"
            notch="/img/notch-2.png"
            notchClassName="status-bar-2"
            overlapGroupClassName="design-component-instance-node"
            statusIconsClassName="status-bar-3"
            timeLightColorRedClassName="status-bar-5"
          />
          <User className="user-instance" user="/img/user-1.png" />
          <div className="text-wrapper-7">The Fridge !</div>
          <div className="overlap-group-wrapper">
            <div className="overlap-group-2">
              <div className="text-wrapper-3">Brown Eggs</div>
              <div className="text-wrapper-4">1 day</div>
              <img className="icon-trash-4" alt="Icon trash" src="/img/icon-trash-2.png" />
              <img className="icon-half-cookie" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
            </div>
          </div>
        </div>
        <div className="div-wrapper">
          <div className="overlap-3">
            <img className="rectangle-stroke" alt="Rectangle stroke" src="/img/rectangle-192-stroke.png" />
            <div className="text-wrapper-8">Mangoes</div>
            <div className="text-wrapper-9">9 days</div>
            <img className="icon-trash-5" alt="Icon trash" src="/img/icon-trash.png" />
            <img className="icon-half-cookie-4" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
          </div>
        </div>
        <div className="group-3">
          <div className="overlap-4">
            <div className="rectangle" />
            <div className="text-wrapper-3">Apples</div>
            <div className="text-wrapper-5">7 days</div>
            <img className="icon-trash-6" alt="Icon trash" src="/img/icon-trash.png" />
            <img className="icon-half-cookie-5" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
          </div>
        </div>
        <div className="group-4">
          <div className="overlap-5">
            <div className="ellipse-2" />
            <img className="icon-menu" alt="Icon menu" src="/img/icon-menu.png" />
            <img className="icon-shopping-bag" alt="Icon shopping bag" src="/img/icon-shopping-bag.png" />
            <div className="ellipse-3" />
            <img className="icon-home" alt="Icon home" src="/img/icon-home.png" />
          </div>
        </div>
        <div className="overlap-6">
          <div className="group-5">
            <div className="overlap-7">
              <img className="rectangle-stroke" alt="Rectangle stroke" src="/img/rectangle-192-stroke.png" />
              <div className="text-wrapper-3">Brown Bread</div>
              <div className="text-wrapper-10">11 days</div>
              <img className="icon-trash-7" alt="Icon trash" src="/img/icon-trash.png" />
              <img className="icon-half-cookie-6" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
            </div>
          </div>
          <div className="group-6">
            <div className="overlap-3">
              <img className="rectangle-stroke" alt="Rectangle stroke" src="/img/rectangle-192-stroke.png" />
              <div className="text-wrapper-3">Onions</div>
              <div className="text-wrapper-11">12 days</div>
              <img className="icon-trash-8" alt="Icon trash" src="/img/icon-trash.png" />
              <img className="icon-half-cookie-7" alt="Icon half cookie" src="/img/icon-half-cookie.png" />
            </div>
          </div>
        </div>
        <div className="rectangle-2" />
      </div>
    </div>
  );
};
