export { DaFridge } from "./DaFridge";
