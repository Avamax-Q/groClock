import React from "react";
import { StatusBar } from "../../components/StatusBar";
import { User } from "../../components/User";
import "./style.css";

export const MainPage = () => {
  return (
    <div className="main-page">
      <div className="div">
        <div className="overlap">
          <div className="ellipse" />
          <StatusBar
            className="status-bar-instance"
            darkMode={false}
            indicatorTypeCameraClassName="status-bar-4"
            notch="/img/notch-2.png"
            notchClassName="status-bar-2"
            overlapGroupClassName="design-component-instance-node"
            statusIconsClassName="status-bar-3"
            timeLightColorRedClassName="status-bar-5"
          />
          <User className="user-instance" user="/img/user-1.png" />
          <div className="text-wrapper">Zero Waste, Full Flavor</div>
        </div>
        <div className="overlap-2">
          <div className="ellipse-2" />
          <img className="icon-menu" alt="Icon menu" src="/img/icon-menu.png" />
          <img className="icon-shopping-bag" alt="Icon shopping bag" src="/img/icon-shopping-bag.png" />
          <div className="ellipse-3" />
          <img className="icon-camera" alt="Icon camera" src="/img/icon-camera.png" />
        </div>
        <div className="frame" />
        <div className="group">
          <div className="rectangle" />
          <div className="text-wrapper-2">Explore recipes</div>
        </div>
        <div className="group-2">
          <div className="rectangle-2" />
          <div className="text-wrapper-2">Your food Calendar</div>
        </div>
        <img className="img" alt="Group" src="/img/group-80.png" />
        <div className="overlap-3">
          <div className="rectangle-3" />
          <div className="text-wrapper-3">Streak</div>
        </div>
      </div>
    </div>
  );
};
