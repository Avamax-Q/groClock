import React from "react";
import { NetworkSignalLight } from "../../components/NetworkSignalLight";
import { TimeLight } from "../../components/TimeLight";
import { User } from "../../components/User";
import { WifiSignalLight } from "../../components/WifiSignalLight";
import "./style.css";

export const Register = () => {
  return (
    <div className="register">
      <div className="div">
        <div className="overlap">
          <img className="ellipse" alt="Ellipse" src="/img/ellipse-48.png" />
          <img className="img" alt="Ellipse" src="/img/ellipse-47.png" />
          <img className="group" alt="Group" src="/img/group-77.png" />
          <img className="india-IN" alt="India IN" src="/img/india-in.png" />
          <img className="img-2" alt="Register" src="/img/register.png" />
          <div className="status-bar">
            <div className="overlap-group">
              <img className="notch" alt="Notch" src="/img/notch-2.png" />
              <div className="status-icons">
                <NetworkSignalLight className="design-component-instance-node" strength="three-bars" />
                <WifiSignalLight className="design-component-instance-node" property1="three-bars" />
                <img className="battery-light" alt="Battery light" src="/img/battery-light.png" />
              </div>
              <TimeLight className="time-light-instance" color="clear" />
            </div>
          </div>
          <User className="user-instance" user="/img/user-1.png" />
          <p className="grocery-clock">
            <span className="text-wrapper">Grocery </span>
            <span className="span">Clock</span>
          </p>
        </div>
        <div className="overlap-group-wrapper">
          <div className="div-wrapper">
            <div className="text-wrapper-2">Proceed to Verify</div>
          </div>
        </div>
        <div className="overlap-wrapper">
          <div className="overlap-2">
            <div className="text-wrapper-3">Enter Email ID</div>
            <img className="rectangle-stroke" alt="Rectangle stroke" src="/img/rectangle-192-stroke.png" />
          </div>
        </div>
        <div className="overlap-3">
          <div className="group-2">
            <div className="overlap-4">
              <div className="text-wrapper-3">Enter password</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-4">
              <div className="text-wrapper-3">Enter password</div>
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-4">
              <div className="text-wrapper-3">Enter password</div>
            </div>
          </div>
        </div>
        <div className="group-3">
          <div className="overlap-4">
            <div className="text-wrapper-3">Verify Password</div>
          </div>
        </div>
        <div className="group-4">
          <div className="overlap-5">
            <div className="text-wrapper-4">Enter Name</div>
          </div>
        </div>
      </div>
    </div>
  );
};
